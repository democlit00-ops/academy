import { useEffect, useMemo, useState } from 'react'
import { Plus, Trash2, Save, Dumbbell, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import type { WorkoutSession, WorkoutExercise, WorkoutSet, WeekDay, MuscleGroup } from '@/types'
import { calculateExerciseVolume } from '@/lib/calculations'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'

interface WorkoutFormProps {
  onSave: (workout: WorkoutSession) => void
  selectedUserId?: string | null
  selectedUserLabel?: string | null
}

type DbExercise = {
  id: string
  name: string
  muscle_group: string
  type: 'strength' | 'cardio'
  is_active: boolean
}

type DbPlanItem = {
  id: string
  block: 'strength' | 'cardio'
  sets: number | null
  reps: string | null
  target_weight: number | null
  notes: string | null
  duration_min: number | null
  sort_order: number
  custom_exercise_name: string | null
  exercises?: { name: string } | null
  exercise_id: string | null
  muscle_group: string | null
}

const WEEK_DAYS: WeekDay[] = [
  'Segunda',
  'Terça',
  'Quarta',
  'Quinta',
  'Sexta',
  'Sábado',
  'Domingo',
] as WeekDay[]

function weekDayToNumber(day: WeekDay): number {
  const map: Record<string, number> = {
    Segunda: 1,
    Terça: 2,
    Quarta: 3,
    Quinta: 4,
    Sexta: 5,
    Sábado: 6,
    Domingo: 7,
  }
  return map[day] ?? 1
}

function parseRepsToNumber(repsText: string | null): number {
  if (!repsText) return 10
  const m = repsText.match(/\d+/)
  if (!m) return 10
  const n = parseInt(m[0], 10)
  return Number.isFinite(n) ? n : 10
}

export function WorkoutForm({
  onSave,
  selectedUserId,
  selectedUserLabel,
}: WorkoutFormProps) {
  const { user } = useAuth()
  const isStudentMode = !!selectedUserId

  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [weekDay, setWeekDay] = useState<WeekDay>(
    (format(new Date(), 'EEEE', { locale: ptBR }).charAt(0).toUpperCase() +
      format(new Date(), 'EEEE', { locale: ptBR }).slice(1)) as WeekDay
  )

  const [exercises, setExercises] = useState<WorkoutExercise[]>([])
  const [loadingPlan, setLoadingPlan] = useState(false)
  const [dbExercises, setDbExercises] = useState<DbExercise[]>([])

  const dbExercisesById = useMemo(() => {
    const map = new Map<string, DbExercise>()
    dbExercises.forEach((e) => map.set(e.id, e))
    return map
  }, [dbExercises])

  useEffect(() => {
    const loadExercises = async () => {
      try {
        const { data, error } = await supabase
          .from('exercises')
          .select('id,name,muscle_group,type,is_active')
          .eq('is_active', true)
          .order('name', { ascending: true })

        if (error) throw error
        setDbExercises((data ?? []) as DbExercise[])
      } catch (e: any) {
        toast.error(e?.message ?? 'Erro ao carregar lista de exercícios.')
      }
    }

    void loadExercises()
  }, [])

  useEffect(() => {
    if (!user) return

    const loadPlanForDay = async () => {
      setLoadingPlan(true)
      try {
        const { data: active, error: activeErr } = await supabase
          .from('user_active_plan')
          .select('active_split_id, active_program_id')
          .eq('user_id', user.id)
          .maybeSingle()

        if (activeErr) throw activeErr

        const activePlanId = active?.active_split_id || active?.active_program_id || null
        if (!activePlanId) {
          setLoadingPlan(false)
          return
        }

        const weekdayNum = weekDayToNumber(weekDay)

        const { data: dayRow, error: dayErr } = await supabase
          .from('plan_days')
          .select('id,weekday,day_title')
          .eq('plan_id', activePlanId)
          .eq('weekday', weekdayNum)
          .maybeSingle()

        if (dayErr) throw dayErr
        if (!dayRow?.id) {
          setLoadingPlan(false)
          return
        }

        const { data: items, error: itemsErr } = await supabase
          .from('plan_items')
          .select(
            `
            id,block,sets,reps,target_weight,notes,duration_min,sort_order,custom_exercise_name,exercise_id,muscle_group,
            exercises:exercise_id ( name )
          `
          )
          .eq('plan_day_id', dayRow.id)
          .order('sort_order', { ascending: true })

        if (itemsErr) throw itemsErr

        const planItems = (items ?? []) as any as DbPlanItem[]
        const strengthItems = planItems.filter((it) => it.block === 'strength')

        const mapped: WorkoutExercise[] = strengthItems.map((it) => {
          const exId = it.exercise_id ?? ''
          const exName = it.exercises?.name ?? it.custom_exercise_name ?? 'Exercício'
          const mg = (it.muscle_group ||
            (dbExercisesById.get(exId)?.muscle_group ?? 'Peito')) as MuscleGroup

          const setsCount = Math.max(it.sets ?? 1, 1)
          const repsN = parseRepsToNumber(it.reps)
          const weight = typeof it.target_weight === 'number' ? Number(it.target_weight) : 0

          const sets: WorkoutSet[] = Array.from({ length: setsCount }).map(() => ({
            reps: repsN,
            weight: weight,
          }))

          return {
            id: crypto.randomUUID(),
            exerciseId: exId,
            exerciseName: exName,
            muscleGroup: mg,
            sets,
            rpe: 7,
            notes: it.notes ?? undefined,
          }
        })

        setExercises((prev) => (prev.length === 0 ? mapped : prev))
      } catch (e: any) {
        toast.error(e?.message ?? 'Erro ao carregar treino do dia do plano ativo.')
      } finally {
        setLoadingPlan(false)
      }
    }

    void loadPlanForDay()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, date, weekDay, dbExercisesById])

  const addExercise = () => {
    const newExercise: WorkoutExercise = {
      id: crypto.randomUUID(),
      exerciseId: '',
      exerciseName: '',
      muscleGroup: 'Peito' as MuscleGroup,
      sets: [{ reps: 10, weight: 0 }],
      rpe: 7,
    }
    setExercises([...exercises, newExercise])
  }

  const removeExercise = (id: string) => {
    setExercises(exercises.filter((e) => e.id !== id))
  }

  const updateExercise = (id: string, updates: Partial<WorkoutExercise>) => {
    setExercises(exercises.map((e) => (e.id === id ? { ...e, ...updates } : e)))
  }

  const addSet = (exerciseId: string) => {
    setExercises(
      exercises.map((e) => {
        if (e.id === exerciseId) {
          const lastSet = e.sets[e.sets.length - 1]
          return {
            ...e,
            sets: [...e.sets, { reps: lastSet?.reps || 10, weight: lastSet?.weight || 0 }],
          }
        }
        return e
      })
    )
  }

  const removeSet = (exerciseId: string, setIndex: number) => {
    setExercises(
      exercises.map((e) => {
        if (e.id === exerciseId) {
          return {
            ...e,
            sets: e.sets.filter((_, i) => i !== setIndex),
          }
        }
        return e
      })
    )
  }

  const updateSet = (exerciseId: string, setIndex: number, updates: Partial<WorkoutSet>) => {
    setExercises(
      exercises.map((e) => {
        if (e.id === exerciseId) {
          return {
            ...e,
            sets: e.sets.map((s, i) => (i === setIndex ? { ...s, ...updates } : s)),
          }
        }
        return e
      })
    )
  }

  const handleExerciseSelect = (exerciseId: string, workoutExerciseId: string) => {
    const ex = dbExercisesById.get(exerciseId)
    if (ex) {
      updateExercise(workoutExerciseId, {
        exerciseId: ex.id,
        exerciseName: ex.name,
        muscleGroup: (ex.muscle_group as MuscleGroup) ?? ('Peito' as MuscleGroup),
      })
    }
  }

  const handleSubmit = () => {
    if (exercises.length === 0) {
      toast.error('Adicione pelo menos um exercício')
      return
    }

    if (exercises.some((e) => !e.exerciseId)) {
      toast.error('Selecione todos os exercícios')
      return
    }

    const totalVolume = exercises.reduce((total, ex) => total + calculateExerciseVolume(ex), 0)

    const workout: WorkoutSession = {
      id: crypto.randomUUID(),
      date,
      weekDay: weekDay as WeekDay,
      exercises,
      totalVolume,
      createdAt: Date.now(),
    }

    onSave(workout)
    toast.success('Treino salvo com sucesso!')

    setDate(format(new Date(), 'yyyy-MM-dd'))
    setExercises([])
  }

  return (
    <div className="space-y-6 pb-20 lg:pb-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Registrar Treino</h1>
          <p className="text-muted-foreground">
            {loadingPlan ? 'Carregando treino do dia do plano ativo...' : 'Registre seus exercícios e cargas'}
          </p>

          {isStudentMode && (
            <div className="mt-2 inline-flex items-center gap-2 rounded-lg border border-primary/30 bg-primary/10 px-3 py-1.5 text-sm text-primary">
              <User className="h-4 w-4" />
              <span>
                Modo Aluno ativo para: <strong>{selectedUserLabel || 'Aluno selecionado'}</strong>
              </span>
            </div>
          )}
        </div>
      </div>

      {isStudentMode && (
        <Card className="border-amber-500/30 bg-amber-500/10">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-amber-500/20 text-amber-300">
                  Somente seus dados
                </Badge>
              </div>
              <p className="text-sm text-amber-100">
                Mesmo com o <strong>Modo Aluno</strong> ativo, esta tela continua registrando apenas os
                <strong> seus próprios treinos</strong>. A visualização do aluno acontece nas telas de consulta.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-primary" />
            Informações do Treino
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Data</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="bg-background border-border"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="weekDay">Dia da Semana</Label>
              <Select value={weekDay} onValueChange={(v) => setWeekDay(v as WeekDay)}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {WEEK_DAYS.map((day) => (
                    <SelectItem key={day} value={day}>
                      {day}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="text-xs text-white/50">
            Dica: se você já ativou um Programa/Split, os exercícios do dia aparecem automaticamente.
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Exercícios</h2>
          <Button onClick={addExercise} variant="outline" className="gap-2">
            <Plus className="w-4 h-4" />
            Adicionar Exercício
          </Button>
        </div>

        {exercises.length === 0 && (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-8 text-center">
              <Dumbbell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                Nenhum exercício adicionado. Clique no botão acima para começar.
              </p>
            </CardContent>
          </Card>
        )}

        {exercises.map((exercise, exIndex) => (
          <Card key={exercise.id} className="bg-card border-border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base text-white">Exercício {exIndex + 1}</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeExercise(exercise.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Exercício</Label>
                <Select
                  value={exercise.exerciseId}
                  onValueChange={(v) => handleExerciseSelect(v, exercise.id)}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Selecione um exercício" />
                  </SelectTrigger>
                  <SelectContent className="max-h-64">
                    {dbExercises.map((ex) => (
                      <SelectItem key={ex.id} value={ex.id}>
                        {ex.name} ({ex.muscle_group})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Séries</Label>
                <div className="space-y-2">
                  {exercise.sets.map((set, setIndex) => (
                    <div key={setIndex} className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground w-12">Série {setIndex + 1}</span>
                      <Input
                        type="number"
                        placeholder="Reps"
                        value={set.reps || ''}
                        onChange={(e) =>
                          updateSet(exercise.id, setIndex, { reps: parseInt(e.target.value) || 0 })
                        }
                        className="w-20 bg-background border-border"
                      />
                      <span className="text-muted-foreground">x</span>
                      <Input
                        type="number"
                        placeholder="Kg"
                        value={set.weight || ''}
                        onChange={(e) =>
                          updateSet(exercise.id, setIndex, { weight: parseFloat(e.target.value) || 0 })
                        }
                        className="w-24 bg-background border-border"
                      />
                      <span className="text-muted-foreground">kg</span>
                      {exercise.sets.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeSet(exercise.id, setIndex)}
                          className="text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
                <Button variant="outline" size="sm" onClick={() => addSet(exercise.id)} className="mt-2">
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar Série
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>RPE (1-10): {exercise.rpe}</Label>
                  <Slider
                    value={[exercise.rpe]}
                    onValueChange={([v]) => updateExercise(exercise.id, { rpe: v })}
                    min={1}
                    max={10}
                    step={1}
                  />
                </div>
                <div className="space-y-2">
                  <Label>FC Média (bpm)</Label>
                  <Input
                    type="number"
                    placeholder="Opcional"
                    value={exercise.avgHeartRate || ''}
                    onChange={(e) =>
                      updateExercise(exercise.id, {
                        avgHeartRate: parseInt(e.target.value) || undefined,
                      })
                    }
                    className="bg-background border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label>FC Máxima (bpm)</Label>
                  <Input
                    type="number"
                    placeholder="Opcional"
                    value={exercise.maxHeartRate || ''}
                    onChange={(e) =>
                      updateExercise(exercise.id, {
                        maxHeartRate: parseInt(e.target.value) || undefined,
                      })
                    }
                    className="bg-background border-border"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Observações</Label>
                <Input
                  placeholder="Notas sobre o exercício..."
                  value={exercise.notes || ''}
                  onChange={(e) => updateExercise(exercise.id, { notes: e.target.value })}
                  className="bg-background border-border"
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {exercises.length > 0 && (
        <div className="flex justify-end">
          <Button onClick={handleSubmit} size="lg" className="gap-2">
            <Save className="w-5 h-5" />
            Salvar Treino
          </Button>
        </div>
      )}
    </div>
  )
}